
let container = null;
export function bootstrap() { return Promise.resolve(); }
export function mount() {
  container = document.getElementById('app-root');
  container.innerHTML = `<h1>Catálogo</h1>`;
  return Promise.resolve();
}
export function unmount() {
  if (container) container.innerHTML = '';
  return Promise.resolve();
}
