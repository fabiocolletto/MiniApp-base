
import { registerApplication, start } from 'single-spa';

const loader = async (url) => {
  try { return await import(url); }
  catch { return await import('/fallback.js'); }
};

registerApplication({
  name: '5horas-home',
  app: () => loader('/docs/microapps/home/Home.js'),
  activeWhen: (loc) => loc.pathname === '/' || loc.pathname === '/home'
});

registerApplication({
  name: '5horas-educacao',
  app: () => loader('/docs/microapps/educacao/Educacao.js'),
  activeWhen: (loc) => loc.pathname.startsWith('/educacao')
});

registerApplication({
  name: '5horas-catalogo',
  app: () => loader('/docs/microapps/catalogo/Catalogo.js'),
  activeWhen: (loc) => loc.pathname.startsWith('/catalogo')
});

registerApplication({
  name: '5horas-perfil',
  app: () => loader('/docs/microapps/perfil/Perfil.js'),
  activeWhen: (loc) => loc.pathname.startsWith('/perfil')
});

start();
